<?php
require_once('head.php');
//require('fpdf/fpdf.php');
/*
https://www.techrepublic.com/article/generating-pdf-files-with-php-and-fpdf/

class PDF extends FPDF
{
	function Header()
		{
			$this->Image('logo.png',10,8,33);
			$this->SetFont('Helvetica','B',15);
			$this->SetXY(50, 10);
			$this->Cell(0,10,'This is a header',1,0,'C');
		 }

	function Footer()
		{
			$this->SetXY(100,-15);
			$this->SetFont('Helvetica','I',10);
			$this->Write (5, 'This is a footer');
		}
}

$pdf=new PDF();
$pdf->AddPage();
$pdf->SetDisplayMode(real,'default');
$pdf->SetXY(50,20);
$pdf->SetDrawColor(50,60,100);
$pdf->Cell(100,10,'FPDF Tutorial',1,0,'C',0);
$pdf->SetXY(10,50);
$pdf->SetFontSize(10);
$pdf->Write(5,'Congratulations! You have generated a PDF. ');
$pdf->Output('example2.pdf','D');
?>
*/

class details{
	public $last_name;
	public $first_name;
	public $phone;
	public $email;
	public $address;
	public $city;
	public $zip;
	public $hosting;
	public $errors = array();
	public $errorFields = array();
	function __construct($last_name, $first_name, $phone, $email, $address, $city, $zip, $hosting)
	 {
			$this->last_name = $last_name;
			$this->first_name = $first_name;
			$this->phone = $phone;
			$this->email = $email;
			$this->address = $address;
			$this->city = $city;
			$this->zip = $zip;
			$this->hosting = $hosting;
	 }
	
	function exists($att)
	{
		return $_REQUEST['first_name'] ? $_REQUEST['first_name'] : "";
	}
	
	function checkValid()
	{
		$fn = $this->last_name;
		$ln = $this->first_name;
		$ph = $this->phone;
		$em = $this->email;
		$ad = $this->address;
		$ci = $this->city;
		$zp = $this->zip;
		$hs = $this->hosting;
		
		if (!empty($fn)) {
				$pattern = "/^\pL[\pL ']+\z/";// This is a regular expression that checks if the name is valid characters
				
				if (preg_match($pattern,$fn)){ 
					$this->first_name = $_REQUEST['first_name'];
					}
				
				else{ $this->errors[] = 'Your name can only contain \', A-Z or a-z and atleast 2 char long.';}
		} else {$this->$errorFields[] = 'first name.';}
		
		
		if (!empty($ln)) {
				$pattern = "/^\pL[\pL ']+\z/"; 
				//"/^[a-zA-Z]{2,40}/";// This is a regular expression that checks if the name is valid characters
				
				if (preg_match($pattern,$ln)){  
					$this->last_name = $_REQUEST['last_name'];
					}
				
				else{ $this->errors[] = 'Your name can only contain \' , A-Z or a-z and atleast 2 char long.';}
		} else {$this->errorFields[] = 'last name.';}
		
		if (!empty($ph)) {
				$pattern = "/^[0-9\_\+]{7,20}/";
				
				if (preg_match($pattern,$ph)){ $this->phone = $_REQUEST['phone'];}
				
				else{ $this->errors[] = 'Your Phone number can only be numbers.';}
		} else {$this->errorFields[] = 'phone number.';}
		
		if (!empty($em)) {
				
				$em = htmlspecialchars($em);
			
				if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/",$em))
				{
					echo "<div class=\"alert alert-success\">E-mail address not valid</div>";
				}
		} else {$this->errorFields[] = 'email address';}
	
		if (!empty($ct)) {
				$pattern = "/^\pL[\pL ']+\z/";// This is a regular expression that checks if the name is valid characters
				
				if (preg_match($pattern,$fn)){ 
					$this->first_name = $_REQUEST['first_name'];
					}
				
				else{ $this->errors[] = 'Your name can only contain \', A-Z or a-z and atleast 2 char long.';}
		} else {$this->errorFields[] = 'city';}
		
		if (!empty($zp)) {
				$pattern = "/^[\pD]+\z/";// This is a regular expression that checks if the name is valid characters
				
				if (preg_match($pattern,$fn)){ 
					$this->first_name = $_REQUEST['zip'];
					}
				
				else{ $this->errors[] = 'Your zipcode is invalid';}
		} else {$this->errorFields[] = 'zipcode';}



	}
} 
?>




<?php
if (isset($_REQUEST['submit'])) {
		
		//check whether optional attributes exist 
		foreach (array('hosting') as $key){
			if(!isset($_REQUEST[$key])){
				 $_REQUEST[$key] = "";
			}
		}
		
		$mydet = new details($_REQUEST['first_name'], $_REQUEST['last_name'], $_REQUEST['phone'], $_REQUEST['email'], 															$_REQUEST['address'], $_REQUEST['city'], $_REQUEST['zip'], $_REQUEST['hosting']);
		$mydet->checkValid();
		
		if (!empty($mydet->errors)) { 
				
				foreach ($mydet->errors as $msg) { echo '<div class="alert alert-warning"><li>'. $msg . '</li></div>';}
				echo '</ul><h3>Your mail could not be sent due to input errors.</h3><hr /></div>';
		}
		
		else{
				echo printf('<center><div class="alert alert-success" role="alert" id="success_message"> <i class="glyphicon glyphicon-thumbs-up"></i>Thank You %s ! </br>
				Your message was sent to our Support Team. You should receive a reply from a representative of our web site by the end of the next business day by email at creeds@van.org. Occasionally we receive a very large number of messages, and your response may take a little longer. If this occurs, we appreciate your patience, and we assure you that you will receive a response. Thank you for taking the time to contact us. Have a great day, Ourwebsite.com Support Team.</div><center>',$mydet->first_name); 
		}
	
}
else{
	echo "<center>Please fill the form.</center>";
}

?>



	<body class="wrapper">

					<div class="container">
						<center><h1>Welcome</h1></center>
						
						<form class="form-group " action="form2.php" method="post"  id="contact_form">
											<input  name="first_name" placeholder="First Name" class="form-control"  type="text">							
											<input name="last_name" placeholder="Last Name" class="form-control"  type="text">
											<input name="email" placeholder="E-Mail Address" class="form-control"  type="text">
											<input name="phone" placeholder="Phone no." class="form-control" type="text">
											<input name="address" placeholder="Address" class="form-control" type="text">
											<input name="city" placeholder="city" class="form-control"  type="text">
											<input name="zip" placeholder="zip code" class="form-control"  type="text">
										<select name="state" class="form-control selectpicker" >
												<option value=" " >Please select your state</option>
												<option>Alabama</option>
												<option>Alaska</option>
												<option >Arizona</option>
												<option >Arkansas</option>
												<option >California</option>
												<option >Colorado</option>
												<option >Connecticut</option>
												<option >Delaware</option>
												<option >District of Columbia</option>
												<option> Florida</option>
												<option >Georgia</option>
												<option >Hawaii</option>
												<option >daho</option>
												<option >Illinois</option>
												<option >Indiana</option>
												<option >Iowa</option>
												<option> Kansas</option>
												<option >Kentucky</option>
												<option >Louisiana</option>
												<option>Maine</option>
												<option >Maryland</option>
												<option> Mass</option>
												<option >Michigan</option>
												<option >Minnesota</option>
												<option>Mississippi</option>
												<option>Missouri</option>
												<option>Montana</option>
												<option>Nebraska</option>
												<option>Nevada</option>
												<option>New Hampshire</option>
												<option>New Jersey</option>
												<option>New Mexico</option>
												<option>New York</option>
												<option>North Carolina</option>
												<option>North Dakota</option>
												<option>Ohio</option>
												<option>Oklahoma</option>
												<option>Oregon</option>
												<option>Pennsylvania</option>
												<option>Rhode Island</option>
												<option>South Carolina</option>
												<option>South Dakota</option>
												<option>Tennessee</option>
												<option>Texas</option>
												<option> Uttah</option>
												<option>Vermont</option>
												<option>Virginia</option>
												<option >Washington</option>
												<option >West Virginia</option>
												<option>Wisconsin</option>
												<option >Wyoming</option>
											</select>
																			
									<center><button type="submit" name="submit" margin="0px" >Submit</button></center>
							
							
						</form>
					</div>
					

					<ul class="bg-bubbles">
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
						<li></li>
					</ul>
				  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

				  

				    <script  src="js/index.js"></script>

		
		</body>
</html>







